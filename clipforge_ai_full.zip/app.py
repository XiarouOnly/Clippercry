import os, re, uuid, json, math, shutil, subprocess, threading, time
from pathlib import Path
from typing import Optional
from fastapi import FastAPI, HTTPException, BackgroundTasks
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse
from pydantic import BaseModel, HttpUrl, Field

ROOT=Path(__file__).parent
WORK=ROOT/"work"; WORK.mkdir(exist_ok=True)
JOBS={}
LOCK=threading.Lock()
app=FastAPI(title="ClipForge AI Full")

class AnalyzeRequest(BaseModel):
    url: HttpUrl
    max_clips: int=8
    clip_min: int=20
    clip_max: int=60
    layout: str="auto"
    subtitles: bool=True
    language: str="auto"

def update(jid, **kw):
    with LOCK:
        JOBS[jid]={**JOBS.get(jid,{}),**kw}

def run(cmd, timeout=None):
    p=subprocess.run(cmd,capture_output=True,text=True,timeout=timeout)
    if p.returncode: raise RuntimeError((p.stderr or p.stdout)[-3500:])
    return p.stdout

def probe(path):
    raw=run(["ffprobe","-v","error","-show_streams","-show_format","-of","json",str(path)])
    d=json.loads(raw); v=next((s for s in d["streams"] if s["codec_type"]=="video"),{})
    return {"duration":float(d["format"].get("duration",0)),"width":int(v.get("width",0)),
            "height":int(v.get("height",0)),"fps":v.get("avg_frame_rate","0/1")}

def download(url, folder):
    # yt-dlp is used only for content the user is authorized to download/process.
    out=str(folder/"source.%(ext)s")
    run(["yt-dlp","--no-playlist","--no-warnings","-f","bv*+ba/b","--merge-output-format","mp4",
         "--max-filesize","5G","-o",out,str(url)],timeout=3600)
    files=[p for p in folder.glob("source.*") if p.suffix.lower() in (".mp4",".mkv",".webm",".mov")]
    if not files: raise RuntimeError("Video sumber tidak ditemukan setelah proses unduh.")
    return files[0]

def get_transcript(src, folder, language):
    try:
        import whisper
        model=whisper.load_model(os.getenv("WHISPER_MODEL","base"))
        opts={"verbose":False}
        if language!="auto": opts["language"]=language
        result=model.transcribe(str(src),**opts)
        segs=result.get("segments",[])
        # SRT file
        def stamp(x):
            ms=int(x*1000); h=ms//3600000; m=(ms%3600000)//60000; s=(ms%60000)//1000; z=ms%1000
            return f"{h:02}:{m:02}:{s:02},{z:03}"
        lines=[]
        for i,s in enumerate(segs,1):
            lines += [str(i),f"{stamp(s['start'])} --> {stamp(s['end'])}",s.get("text","").strip(),""]

        (folder/"transcript.srt").write_text("\\n".join(lines),encoding="utf-8")
        return segs, True
    except Exception as e:
        return [], False

def face_layout(src, folder, width, height, duration):
    # Optional OpenCV Haar detector. Finds the most persistent face region across sampled frames.
    try:
        import cv2
        cap=cv2.VideoCapture(str(src))
        cascade=cv2.CascadeClassifier(cv2.data.haarcascades+"haarcascade_frontalface_default.xml")
        samples=min(24,max(8,int(duration/20)))
        found=[]
        for i in range(samples):
            cap.set(cv2.CAP_PROP_POS_MSEC,(duration*(i+0.5)/samples)*1000)
            ok,frame=cap.read()
            if not ok: continue
            gray=cv2.cvtColor(frame,cv2.COLOR_BGR2GRAY)
            faces=cascade.detectMultiScale(gray,1.1,5,minSize=(max(30,width//18),max(30,height//18)))
            if len(faces):
                x,y,w,h=max(faces,key=lambda b:b[2]*b[3])
                found.append((x,y,w,h))
        cap.release()
        if not found: return None
        # Median box reduces jitter and false positives.
        xs=sorted(x for x,y,w,h in found); ys=sorted(y for x,y,w,h in found)
        ws=sorted(w for x,y,w,h in found); hs=sorted(h for x,y,w,h in found)
        mid=len(found)//2
        x,y,w,h=xs[mid],ys[mid],ws[mid],hs[mid]
        # Widen around the detected face to capture shoulders and expression.
        cw=min(width,max(int(w*3.1),int(height*0.55)))
        ch=min(height,max(int(h*3.7),int(cw*1.05)))
        cx=x+w//2; cy=y+h//2
        x0=max(0,min(width-cw,cx-cw//2)); y0=max(0,min(height-ch,cy-ch//2))
        return {"x":int(x0),"y":int(y0),"w":int(cw),"h":int(ch),"confidence":"best-effort","samples":len(found)}
    except Exception:
        return None

def score_candidates(segs,duration,minlen,maxlen,limit):
    if not segs:
        step=max(minlen,min(maxlen,40))
        starts=list(range(0,max(1,int(duration-minlen)),max(12,step//2)))
        return [{"start":float(s),"end":float(min(duration,s+step)),"score":max(45,68-(i%5)*3),
                 "reason":"Kandidat fallback berdasarkan cakupan durasi; transkrip belum tersedia."} for i,s in enumerate(starts[:limit])]
    triggers=["wkwk","haha","anjir","gila","waduh","astaga","serius","akhirnya","ternyata","menang","kalah","clutch","kill","ace","epic","no way","wow","what","bro","parah","lucu","kocak","mantap","nice"]
    raw=[]
    for i,s in enumerate(segs):
        txt=(s.get("text") or "").strip(); low=txt.lower()
        if not txt: continue
        start=max(0,float(s["start"])-8); end=min(duration,float(s["end"])+14)
        if end-start<minlen: start=max(0,end-minlen)
        if end-start>maxlen: end=start+maxlen
        score=48+min(18,len(txt)//10)
        score+=sum(8 for w in triggers if w in low)
        score+=4*("!" in txt)+3*("?" in txt)
        # speech intensity proxy: segments with dense speech often contain context-rich moments
        score+=min(8,int(len(txt)/max(1,float(s["end"])-float(s["start"]))*0.45))
        raw.append({"start":start,"end":end,"score":min(99,int(score)),
                    "reason":txt[:220]})
    raw.sort(key=lambda c:c["score"],reverse=True)
    chosen=[]
    for c in raw:
        if all(abs(c["start"]-p["start"])>minlen*0.8 for p in chosen):
            chosen.append(c)
        if len(chosen)>=limit: break
    return sorted(chosen,key=lambda c:c["start"])

def ffmpeg_render(src,out,start,end,face,width,height,subtitle_path=None):
    # Split layout: detected face crop in upper panel, full gameplay source in lower panel.
    # Each panel is scaled/cropped independently to fill its half of a 9:16 canvas.
    top_h=760; bottom_h=1160; target_w=1080
    if face:
        x,y,w,h=face["x"],face["y"],face["w"],face["h"]
        face_vf=f"crop={w}:{h}:{x}:{y},scale={target_w}:{top_h}:force_original_aspect_ratio=increase,crop={target_w}:{top_h}"
    else:
        # Conservative upper band fallback when face detector cannot identify a face.
        band_h=max(1,int(height*0.48))
        face_vf=f"crop={width}:{band_h}:0:0,scale={target_w}:{top_h}:force_original_aspect_ratio=increase,crop={target_w}:{top_h}"
    game_vf=f"scale={target_w}:{bottom_h}:force_original_aspect_ratio=increase,crop={target_w}:{bottom_h}"
    graph=f"[0:v]split=2[a][b];[a]{face_vf}[top];[b]{game_vf}[bottom];[top][bottom]vstack=inputs=2[v]"
    if subtitle_path and subtitle_path.exists():
        # Burn subtitles over the final composite, with safe style and escaped path.
        p=str(subtitle_path).replace("\\\\","/").replace(":","\\\\:")
        graph+=f";[v]subtitles='{p}':force_style='FontName=Arial,FontSize=17,PrimaryColour=&H00FFFFFF,OutlineColour=&H00000000,BorderStyle=1,Outline=3,Shadow=1,Alignment=2,MarginV=55'[outv]"
        vmap="[outv]"
    else: vmap="[v]"
    run(["ffmpeg","-y","-ss",str(start),"-i",str(src),"-t",str(max(1,end-start)),
         "-filter_complex",graph,"-map",vmap,"-map","0:a?","-c:v","libx264","-preset","veryfast",
         "-crf","22","-c:a","aac","-b:a","160k","-movflags","+faststart",str(out)],timeout=1800)

def make_clip_srt(segs,start,end,path):
    if not segs: return None
    def stamp(x):
        ms=max(0,int(x*1000)); h=ms//3600000; m=(ms%3600000)//60000; s=(ms%60000)//1000; z=ms%1000
        return f"{h:02}:{m:02}:{s:02},{z:03}"
    lines=[]; idx=0
    for seg in segs:
        a=max(start,float(seg["start"])); b=min(end,float(seg["end"]))
        txt=(seg.get("text") or "").strip()
        if b<=a or not txt: continue
        idx+=1; lines += [str(idx),f"{stamp(a-start)} --> {stamp(b-start)}",txt,""]
    if not lines: return None
    path.write_text("\\n".join(lines),encoding="utf-8")
    return path

def process(jid,p):
    folder=WORK/jid; folder.mkdir(parents=True,exist_ok=True)
    try:
        update(jid,status="downloading",progress=5,message="Mengambil video YouTube…")
        src=download(p["url"],folder)
        meta=probe(src); duration=meta["duration"]
        update(jid,status="analyzing",progress=22,message="Mendeteksi wajah, layout, dan transkrip…",video=meta)
        face=face_layout(src,folder,meta["width"],meta["height"],duration)
        segs,has_transcript=get_transcript(src,folder,p["language"])
        clips=score_candidates(segs,duration,p["clip_min"],p["clip_max"],p["max_clips"])
        update(jid,status="rendering",progress=42,message="Menyusun klip vertikal 9:16…",face_detected=bool(face),
               face_region=face,transcript_available=has_transcript,total=len(clips),clips=[])
        done=[]
        for i,c in enumerate(clips,1):
            name=f"clip_{i:02}.mp4"; sub=None
            if p["subtitles"] and segs:
                sub=make_clip_srt(segs,c["start"],c["end"],folder/f"clip_{i:02}.srt")
            ffmpeg_render(src,folder/name,c["start"],c["end"],face,meta["width"],meta["height"],sub)
            done.append({**c,"file":name,"download":f"/jobs/{jid}/files/{name}"})
            update(jid,status="rendering",progress=42+int(55*i/max(1,len(clips))),
                   message=f"Merender klip {i}/{len(clips)}…",clips=done)
        update(jid,status="done",progress=100,message="Semua klip selesai.",clips=done,
               video=meta,face_detected=bool(face),transcript_available=has_transcript,
               note=("Facecam terdeteksi dan dipakai sebagai panel atas." if face else
                     "Wajah tidak terdeteksi dengan yakin; panel atas memakai area atas video sebagai fallback.")+
                    " Skor adalah estimasi berbasis transkrip, bukan jaminan viral.")
    except Exception as e:
        update(jid,status="error",progress=0,message=str(e))

@app.post("/api/analyze")
def analyze(req:AnalyzeRequest, bg:BackgroundTasks):
    u=str(req.url)
    if not any(host in u for host in ("youtube.com/","youtu.be/")): raise HTTPException(400,"URL YouTube tidak valid.")
    if req.clip_min<10 or req.clip_max<req.clip_min or req.clip_max>180: raise HTTPException(400,"Rentang durasi klip tidak valid.")
    if req.max_clips<1 or req.max_clips>30: raise HTTPException(400,"Jumlah klip harus 1–30.")
    jid=uuid.uuid4().hex[:10]
    JOBS[jid]={"status":"queued","progress":0,"message":"Menunggu worker…"}
    bg.add_task(process,jid,{"url":u,"max_clips":req.max_clips,"clip_min":req.clip_min,
                            "clip_max":req.clip_max,"subtitles":req.subtitles,"language":req.language})
    return {"job_id":jid}

@app.get("/api/jobs/{jid}")
def job(jid):
    if jid not in JOBS: raise HTTPException(404,"Job tidak ditemukan.")
    return JOBS[jid]

@app.get("/jobs/{jid}/files/{filename}")
def get_file(jid,filename):
    path=WORK/jid/filename
    if not path.exists() or path.suffix.lower() not in (".mp4",".srt"): raise HTTPException(404,"File tidak ditemukan.")
    return FileResponse(path,filename=filename)

@app.get("/api/health")
def health():
    def available(cmd):
        return shutil.which(cmd) is not None
    return {"ok":True,"ffmpeg":available("ffmpeg"),"ffprobe":available("ffprobe"),
            "yt_dlp":available("yt-dlp")}

app.mount("/",StaticFiles(directory=ROOT/"static",html=True),name="static")
