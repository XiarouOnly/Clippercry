# ClipForge AI — Full Gaming Clipper MVP

A self-hosted web app prototype for authorized YouTube video processing.

## What it does
- YouTube URL input and configurable clip count/duration.
- Downloads source video with yt-dlp (only use content you are authorized to download/process).
- Uses local Whisper transcription when installed and available.
- Ranks candidate moments using transcript-based heuristics (not a reliable viral prediction).
- Samples frames with OpenCV Haar face detector and estimates a facecam crop.
- Builds vertical 1080x1920 clips: detected face crop in upper panel, source gameplay in lower panel.
- Optionally burns subtitles into each clip.
- Downloads rendered MP4s from the browser dashboard.

## Important limitations
This is a substantial runnable prototype, not a finished hosted SaaS:
- Face detection uses a classic Haar detector; it can miss faces, confuse game art with faces, or crop imperfectly. A robust production version should use a modern face/person detector and let users adjust the crop.
- The gameplay panel currently uses the full source frame, not semantic game-only segmentation.
- Candidate ranking is heuristic; it does not predict views or virality.
- YouTube downloading may be restricted by video settings, account access, copyright, or YouTube Terms. Only process videos you own or have permission to use.
- Whisper/FFmpeg/OpenCV need compute resources; long videos can take time.

## Requirements
Python 3.10 or 3.11; FFmpeg + FFprobe installed and on PATH.
Whisper may require PyTorch; GPU is optional but helps.

### Windows
```powershell
py -3.11 -m venv .venv
.venv\Scripts\activate
pip install -r requirements.txt
uvicorn app:app --host 127.0.0.1 --port 8000
```
Open http://127.0.0.1:8000

### macOS/Linux
```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
uvicorn app:app --host 127.0.0.1 --port 8000
```
Open http://127.0.0.1:8000

## Production hardening still needed
Persistent job queue, authentication, rate limits, storage lifecycle/cleanup, user-adjustable facecam crop, modern person/face detection, rights workflow, and deployment configuration.
