# ClipForge AI

Aplikasi web berbasis Python Flask yang dikonfigurasi untuk deployment di Vercel menggunakan struktur direktori `api/`.

## Struktur Direktori
```text
├── api/
│   └── app.py
├── static/
│   └── index.html
├── requirements.txt
└── vercel.json
```
