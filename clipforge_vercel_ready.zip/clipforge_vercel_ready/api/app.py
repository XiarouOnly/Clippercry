import os
from flask import Flask, send_from_directory

static_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), '../static'))
app = Flask(__name__, static_folder=static_dir)

@app.route('/')
def index():
    return send_from_directory(app.static_folder, 'index.html')

if __name__ == '__main__':
    app.run(debug=True, port=5000)
